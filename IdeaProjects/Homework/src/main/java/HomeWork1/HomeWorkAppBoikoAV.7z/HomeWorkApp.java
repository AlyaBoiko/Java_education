package HomeWork1;

public class HomeWorkApp {
    public static void main(String[] args) {
        printThreeWards();
        checkSumSign();
        printColor();
        compareNumbers();
    }

    private static void printThreeWards() {
        System.out.println("Orange");
        System.out.println("Banana");
        System.out.println("Apple");
    }

    private static void checkSumSign() {
        int varA = 5;
        int varB = 1;

        if (varA + varB >= 0) {
            System.out.println("Сумма положительная");
        } else {
            System.out.println("Сумма отрицательная");
        }

    }

    private static void printColor() {
        int varC = 0;

        if (varC <= 0) {
            System.out.println("Красный");
        } else if (varC > 0 && varC <= 100) {
            System.out.println("Желтый");
        } else {
            System.out.println("Зеленый");
        }

    }


    private static void compareNumbers() {
        int A = 0;
        int B = 1;

        if (A >= B) {
            System.out.println("A >= B");
        } else {
            System.out.println("A < B");
        }
        System.out.println("Проверки окончены");
    }
}
